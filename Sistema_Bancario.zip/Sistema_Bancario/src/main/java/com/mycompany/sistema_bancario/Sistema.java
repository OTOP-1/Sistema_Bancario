/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistema_bancario;

/**
 *
 * @author Aluno Admin
 */


import java.util.ArrayList;

public class Sistema {
    
    private ArrayList<String> usuarios = new ArrayList<>();
    private ArrayList<String> senhas = new ArrayList<>();
    
    public Sistema() {
        // agora começa vazio
    }
    
    public boolean cadastrar(String usuario, String senha) {
        usuarios.add(usuario);
        senhas.add(senha);
        return true;
    }
    
    public boolean autenticar(String usuario, String senha) {
        for(int i = 0; i < usuarios.size(); i++) {
            if(usuarios.get(i).equals(usuario) && senhas.get(i).equals(senha)) {
                return true;
            }
        }
        return false;
    }
}


