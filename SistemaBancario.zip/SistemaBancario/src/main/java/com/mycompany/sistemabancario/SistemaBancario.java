/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.sistemabancario;

/**
 *
 * @author Lucas Montreuil
 */
public class SistemaBancario {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
