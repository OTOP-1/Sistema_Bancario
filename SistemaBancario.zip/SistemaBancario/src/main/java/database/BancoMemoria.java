package database;

import models.Cliente;
import models.ContaBancaria;
import models.Movimentacao;

import java.io.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class BancoMemoria {

    private static final List<Cliente> clientes = new ArrayList<>();
    private static final List<ContaBancaria> contas = new ArrayList<>();
    private static final List<Movimentacao> movimentacoes = new ArrayList<>();
    private static int proximoNumeroConta = 1001;

    private static final String ARQ_CLIENTES = "clientes.txt";
    private static final String ARQ_CONTAS = "contas.txt";
    private static final String ARQ_MOV = "movimentacoes.txt";

    // ---------- inicializa carregando do arquivo ----------
    static {
        carregar();
        // garantir proximoNumeroConta consistente
        int maior = proximoNumeroConta;
        for (ContaBancaria c : contas) {
            try {
                int n = Integer.parseInt(c.getNumeroConta());
                if (n >= maior) maior = n + 1;
            } catch (Exception ignored) {}
        }
        proximoNumeroConta = maior;
    }

    // -------------------- buscas / getters --------------------

    public static Cliente buscarClientePorCpf(String cpf) {
        if (cpf == null) return null;
        for (Cliente cliente : clientes) {
            if (cpf.equals(cliente.getCpf())) return cliente;
        }
        return null;
    }

    public static boolean validarLogin(String cpf, String senha) {
        Cliente cliente = buscarClientePorCpf(cpf);
        return cliente != null && cliente.getSenha() != null && cliente.getSenha().equals(senha);
    }

    public static void cadastrarCliente(Cliente cliente) {
        
        cliente.setId(clientes.size() + 1);
        clientes.add(cliente);

        
        String numeroConta = String.valueOf(proximoNumeroConta++);
        ContaBancaria conta = new ContaBancaria(cliente.getId(), numeroConta, 0.0);
        conta.setId(contas.size() + 1);
        contas.add(conta);

        salvar(); 
    }

    public static ContaBancaria buscarContaPorClienteId(int clienteId) {
        for (ContaBancaria conta : contas) {
            if (conta.getClienteId() == clienteId) return conta;
        }
        return null;
    }

    public static ContaBancaria buscarContaPorNumero(String numero) {
        for (ContaBancaria conta : contas) {
            if (conta.getNumeroConta().equals(numero)) return conta;
        }
        return null;
    }

    public static double consultarSaldo(int clienteId) {
        ContaBancaria c = buscarContaPorClienteId(clienteId);
        return c != null ? c.getSaldo() : 0.0;
    }

    public static List<Cliente> getTodosClientes() {
        return new ArrayList<>(clientes);
    }

    public static List<ContaBancaria> getTodasContas() {
        return new ArrayList<>(contas);
    }

    public static List<Movimentacao> getMovimentacoes() {
        return new ArrayList<>(movimentacoes);
    }

    

    public static boolean sacar(int clienteId, double valor) {
        if (valor <= 0) return false;
        ContaBancaria conta = buscarContaPorClienteId(clienteId);
        if (conta != null && conta.getSaldo() >= valor) {
            conta.setSaldo(conta.getSaldo() - valor);

            Movimentacao m = new Movimentacao(conta.getId(), "SAQUE", valor);
            m.setId(movimentacoes.size() + 1);
            movimentacoes.add(m);

            salvar();
            return true;
        }
        return false;
    }

    public static void depositar(int clienteId, double valor) {
        if (valor <= 0) return;
        ContaBancaria conta = buscarContaPorClienteId(clienteId);
        if (conta != null) {
            conta.setSaldo(conta.getSaldo() + valor);

            Movimentacao m = new Movimentacao(conta.getId(), "DEPOSITO", valor);
            m.setId(movimentacoes.size() + 1);
            movimentacoes.add(m);

            salvar();
        }
    }

    public static boolean transferir(int clienteOrigemId, String numeroContaDestino, double valor) {
        if (valor <= 0) return false;

        ContaBancaria contaOrigem = buscarContaPorClienteId(clienteOrigemId);
        ContaBancaria contaDestino = buscarContaPorNumero(numeroContaDestino);

        if (contaOrigem == null || contaDestino == null) return false;
        if (contaOrigem.getNumeroConta().equals(contaDestino.getNumeroConta())) return false;
        if (contaOrigem.getSaldo() < valor) return false;

        contaOrigem.setSaldo(contaOrigem.getSaldo() - valor);
        contaDestino.setSaldo(contaDestino.getSaldo() + valor);

        Movimentacao m1 = new Movimentacao(contaOrigem.getId(), "TRANSFERENCIA_OUT", valor);
        m1.setId(movimentacoes.size() + 1);
        movimentacoes.add(m1);

        Movimentacao m2 = new Movimentacao(contaDestino.getId(), "TRANSFERENCIA_IN", valor);
        m2.setId(movimentacoes.size() + 1);
        movimentacoes.add(m2);

        salvar();
        return true;
    }

   

    public static boolean removerCliente(int idCliente) {
        // Remove cliente
        boolean removed = clientes.removeIf(c -> c.getId() == idCliente);

        // remove contas do cliente e guarda ids de contas removidas
        List<Integer> contasRemovidas = new ArrayList<>();
        contas.removeIf(ct -> {
            if (ct.getClienteId() == idCliente) {
                contasRemovidas.add(ct.getId());
                return true;
            }
            return false;
        });

        // remove movimentações associadas às contas removidas
        movimentacoes.removeIf(m -> contasRemovidas.contains(m.getContaId()));

        salvar();
        return removed;
    }

   

    public static void salvar() {
        salvarClientes();
        salvarContas();
        salvarMovimentacoes();
    }

    private static void salvarClientes() {
        try (PrintWriter w = new PrintWriter(new FileWriter(ARQ_CLIENTES))) {
            for (Cliente c : clientes) {
                // id;nome;cpf;senha;telefone
                w.println(c.getId() + ";" + escape(c.getNome()) + ";" + c.getCpf() + ";" + escape(c.getSenha()) + ";" + escape(c.getTelefone()));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void salvarContas() {
        try (PrintWriter w = new PrintWriter(new FileWriter(ARQ_CONTAS))) {
            for (ContaBancaria c : contas) {
                // id;clienteId;numeroConta;saldo
                w.println(c.getId() + ";" + c.getClienteId() + ";" + c.getNumeroConta() + ";" + c.getSaldo());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void salvarMovimentacoes() {
        try (PrintWriter w = new PrintWriter(new FileWriter(ARQ_MOV))) {
            for (Movimentacao m : movimentacoes) {
                // id;contaId;tipo;valor;dataISO
                w.println(m.getId() + ";" + m.getContaId() + ";" + escape(m.getTipo()) + ";" + m.getValor() + ";" + m.getDataMovimentacao());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void carregar() {
        carregarClientes();
        carregarContas();
        carregarMovimentacoes();
    }

    private static void carregarClientes() {
        clientes.clear();
        File f = new File(ARQ_CLIENTES);
        if (!f.exists()) return;
        try (BufferedReader r = new BufferedReader(new FileReader(f))) {
            String linha;
            while ((linha = r.readLine()) != null) {
                String[] p = linha.split(";", -1);
                Cliente c = new Cliente();
                c.setId(Integer.parseInt(p[0]));
                c.setNome(unescape(p[1]));
                c.setCpf(p[2]);
                c.setSenha(unescape(p[3]));
                c.setTelefone(unescape(p[4]));
                clientes.add(c);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void carregarContas() {
        contas.clear();
        File f = new File(ARQ_CONTAS);
        if (!f.exists()) return;
        try (BufferedReader r = new BufferedReader(new FileReader(f))) {
            String linha;
            while ((linha = r.readLine()) != null) {
                String[] p = linha.split(";", -1);
                ContaBancaria c = new ContaBancaria();
                c.setId(Integer.parseInt(p[0]));
                c.setClienteId(Integer.parseInt(p[1]));
                c.setNumeroConta(p[2]);
                c.setSaldo(Double.parseDouble(p[3]));
                contas.add(c);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void carregarMovimentacoes() {
        movimentacoes.clear();
        File f = new File(ARQ_MOV);
        if (!f.exists()) return;
        try (BufferedReader r = new BufferedReader(new FileReader(f))) {
            String linha;
            while ((linha = r.readLine()) != null) {
                String[] p = linha.split(";", -1);
                Movimentacao m = new Movimentacao();
                m.setId(Integer.parseInt(p[0]));
                m.setContaId(Integer.parseInt(p[1]));
                m.setTipo(unescape(p[2]));
                m.setValor(Double.parseDouble(p[3]));
                m.setDataMovimentacao(LocalDateTime.parse(p[4]));
                movimentacoes.add(m);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private static String escape(String s) {
        if (s == null) return "";
        return s.replace("\n", "\\n").replace(";", "\\;");
    }

    private static String unescape(String s) {
        if (s == null) return "";
        return s.replace("\\n", "\n").replace("\\;", ";");
    }
}
