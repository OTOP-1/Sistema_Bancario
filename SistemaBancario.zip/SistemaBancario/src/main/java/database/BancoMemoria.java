/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package database;

import models.Cliente;
import models.ContaBancaria;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author K A
 */
public class BancoMemoria {
    private static List<Cliente> clientes = new ArrayList<>();
    private static List<ContaBancaria> contas = new ArrayList<>();
    private static int proximoNumeroConta = 1001;
    
    static {
    }
    
    public static Cliente buscarClientePorCpf(String cpf) {
        for (Cliente cliente : clientes) {
            if (cliente.getCpf().equals(cpf)) {
                return cliente;
            }
        }
        return null;
    }
    
    public static boolean validarLogin(String cpf, String senha) {
        Cliente cliente = buscarClientePorCpf(cpf);
        return cliente != null && cliente.getSenha().equals(senha);
    }
    
    public static void cadastrarCliente(Cliente cliente) {
        cliente.setId(clientes.size() + 1);
        clientes.add(cliente);
        
        String numeroConta = String.valueOf(proximoNumeroConta++);
        ContaBancaria conta = new ContaBancaria(cliente.getId(), numeroConta, 0.0);
        conta.setId(contas.size() + 1);
        contas.add(conta);
    }
    
    public static ContaBancaria buscarContaPorClienteId(int clienteId) {
        for (ContaBancaria conta : contas) {
            if (conta.getClienteId() == clienteId) {
                return conta;
            }
        }
        return null;
    }
    
    public static boolean sacar(int clienteId, double valor) {
        ContaBancaria conta = buscarContaPorClienteId(clienteId);
        if (conta != null && conta.getSaldo() >= valor && valor > 0) {
            conta.setSaldo(conta.getSaldo() - valor);
            return true;
        }
        return false;
    }
    
    public static void depositar(int clienteId, double valor) {
        ContaBancaria conta = buscarContaPorClienteId(clienteId);
        if (conta != null && valor > 0) {
            conta.setSaldo(conta.getSaldo() + valor);
        }
    }
    
    public static boolean transferir(int clienteOrigemId, String numeroContaDestino, double valor) {
        ContaBancaria contaOrigem = buscarContaPorClienteId(clienteOrigemId);
        
        ContaBancaria contaDestino = null;
        for (ContaBancaria conta : contas) {
            if (conta.getNumeroConta().equals(numeroContaDestino)) {
                contaDestino = conta;
                break;
            }
        }
        
        if (contaOrigem != null && contaDestino != null && 
            contaOrigem.getSaldo() >= valor && valor > 0) {
            
            contaOrigem.setSaldo(contaOrigem.getSaldo() - valor);
            contaDestino.setSaldo(contaDestino.getSaldo() + valor);
            return true;
        }
        return false;
    }
    
    public static double consultarSaldo(int clienteId) {
        ContaBancaria conta = buscarContaPorClienteId(clienteId);
        return conta != null ? conta.getSaldo() : 0.0;
    }
    
    public static List<Cliente> getTodosClientes() {
        return new ArrayList<>(clientes);
    }
    
    public static List<ContaBancaria> getTodasContas() {
        return new ArrayList<>(contas);
    }
    
    public static void listarTodasContas() {
        System.out.println("CONTAS NO SISTEMA:");
        for (ContaBancaria conta : contas) {
            Cliente cliente = buscarClientePorId(conta.getClienteId());
            System.out.println("Conta: " + conta.getNumeroConta() + " | Cliente: " + cliente.getNome() + " | Saldo: R$ " + String.format("%.2f", conta.getSaldo()));
        }
    }
    
    private static Cliente buscarClientePorId(int id) {
        for (Cliente cliente : clientes) {
            if (cliente.getId() == id) {
                return cliente;
            }
        }
        return null;
    }
}
