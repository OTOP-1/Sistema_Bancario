/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package models;

/**
 *
 * @author K A
 */
public class ContaBancaria {
    private int id;
    private int clienteId;
    private String numeroConta;
    private double saldo;
    
    public ContaBancaria() {}
    
    public ContaBancaria(int clienteId, String numeroConta, double saldo) {
        this.clienteId = clienteId;
        this.numeroConta = numeroConta;
        this.saldo = saldo;
    }
    
    
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public int getClienteId() { return clienteId; }
    public void setClienteId(int clienteId) { this.clienteId = clienteId; }
    
    public String getNumeroConta() { return numeroConta; }
    public void setNumeroConta(String numeroConta) { this.numeroConta = numeroConta; }
    
    public double getSaldo() { return saldo; }
    public void setSaldo(double saldo) { this.saldo = saldo; }
    

    public void depositar(double valor) {
        if (valor > 0) {
            this.saldo += valor;
        }
    }
    
    public boolean sacar(double valor) {
        if (valor > 0 && valor <= saldo) {
            this.saldo -= valor;
            return true;
        }
        return false;
    }
    
    @Override
    public String toString() {
        return "Conta: " + numeroConta + " | Saldo: R$ " + String.format("%.2f", saldo);
    }
}