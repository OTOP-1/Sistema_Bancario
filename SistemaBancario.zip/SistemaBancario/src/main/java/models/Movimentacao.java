/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package models;

import java.time.LocalDateTime;
/**
 *
 * @author K A
 */
public class Movimentacao {
    private int id;
    private int contaId;
    private String tipo;
    private double valor;
    private LocalDateTime dataMovimentacao;
    
    public Movimentacao() {}
    
    public Movimentacao(int contaId, String tipo, double valor) {
        this.contaId = contaId;
        this.tipo = tipo;
        this.valor = valor;
        this.dataMovimentacao = LocalDateTime.now();
    }
    
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public int getContaId() { return contaId; }
    public void setContaId(int contaId) { this.contaId = contaId; }
    
    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }
    
    public double getValor() { return valor; }
    public void setValor(double valor) { this.valor = valor; }
    
    public LocalDateTime getDataMovimentacao() { return dataMovimentacao; }
    public void setDataMovimentacao(LocalDateTime dataMovimentacao) { 
        this.dataMovimentacao = dataMovimentacao; 
    }
    
    @Override
    public String toString() {
        return tipo + " - R$ " + valor + " - " + dataMovimentacao;
    }
}